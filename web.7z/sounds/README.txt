Place small .mp3 or .ogg files here:
- boot.mp3 (terminal start)
- hover.mp3 (menu hover)
- select.mp3 (menu select)

In HTML:
<audio id='boot' src='sounds/boot.mp3' preload='auto'></audio>